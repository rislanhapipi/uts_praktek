import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  StatusBar,
  Alert,
} from "react-native";

export default function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [login, setLogin] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const nama = "M Rislan Hapipi";

  const masuk = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert("Peringatan", "Email dan password harus diisi!");
    } else {
      setLogin(true);
    }
  };

  const logout = () => {
    Alert.alert("Logout", "Yakin ingin keluar?", [
      { text: "Batal", style: "cancel" },
      {
        text: "Keluar",
        onPress: () => {
          setLogin(false);
          setPassword("");
        },
      },
    ]);
  };

  const menu = [
    {
      icon: "👤",
      judul: "Profil",
      deskripsi: "Informasi diri",
    },
    {
      icon: "🔔",
      judul: "Notifikasi",
      deskripsi: "Lihat pemberitahuan",
    },
    {
      icon: "⚙️",
      judul: "Pengaturan",
      deskripsi: "Atur aplikasi",
    },
    {
      icon: "💬",
      judul: "Bantuan",
      deskripsi: "Pusat bantuan",
    },
  ];

  const bukaMenu = (judul) => {
    Alert.alert(judul, "Kamu membuka menu " + judul);
  };

  return (
    <View style={styles.main}>
      <StatusBar backgroundColor="#2563eb" barStyle="light-content" />

      {!login ? (
        <ScrollView
          contentContainerStyle={styles.loginContainer}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.logo}>
            <Text style={styles.logoText}>M</Text>
          </View>

          <Text style={styles.title}>Ulangan Tengah Semester</Text>
          <Text style={styles.subtitle}>Praktek Pemrograman Web</Text>
          <Text style={styles.description}>
            Silakan login untuk melanjutkan
          </Text>

          <View style={styles.form}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              placeholder="Masukkan email kamu"
              placeholderTextColor="#94a3b8"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />

            <Text style={styles.label}>Password</Text>
            <View style={styles.passwordBox}>
              <TextInput
                style={styles.passwordInput}
                placeholder="Masukkan password"
                placeholderTextColor="#94a3b8"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
              />

              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                <Text style={styles.showPassword}>
                  {showPassword ? "Sembunyi" : "Lihat"}
                </Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.loginButton}
              onPress={masuk}
              activeOpacity={0.8}
            >
              <Text style={styles.loginButtonText}>LOGIN SEKARANG →</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.footer}></Text>
        </ScrollView>
      ) : (
        <ScrollView contentContainerStyle={styles.dashboardContainer}>
          <View style={styles.header}>
            <View>
              <Text style={styles.headerSmall}>SELAMAT DATANG 👋</Text>
              <Text style={styles.headerTitle}>HOME</Text>
            </View>

            <View style={styles.headerLogo}>
              <Text style={styles.headerLogoText}>M</Text>
            </View>
          </View>

          <View style={styles.welcomeCard}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>MR</Text>
            </View>

            <View style={styles.profileInfo}>
              <Text style={styles.welcomeText}>Halo, selamat datang!</Text>
              <Text style={styles.name}>{nama}</Text>
              <Text style={styles.emailText}>{email}</Text>
            </View>
          </View>

          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Menu Utama</Text>
            <Text style={styles.sectionSubtitle}>
              Pilih menu yang kamu butuhkan
            </Text>
          </View>

          <View style={styles.menuContainer}>
            {menu.map((item, index) => (
              <TouchableOpacity
                key={item.judul}
                style={styles.menuCard}
                onPress={() => bukaMenu(item.judul)}
                activeOpacity={0.75}
              >
                <View style={styles.menuTop}>
                  <View style={styles.menuIcon}>
                    <Text style={styles.iconText}>{item.icon}</Text>
                  </View>
                  <Text style={styles.menuNumber}>0{index + 1}</Text>
                </View>

                <Text style={styles.menuTitle}>{item.judul}</Text>
                <Text style={styles.menuDescription}>{item.deskripsi}</Text>
                <Text style={styles.menuArrow}>Buka menu →</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.infoIcon}>💡</Text>
            <View style={styles.infoContent}>
              <Text style={styles.infoTitle}>Tips Hari Ini</Text>
              <Text style={styles.infoText}>
                Tetap semangat belajar dan jangan lupa menyelesaikan tugas
                kuliahmu!
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.logoutButton}
            onPress={logout}
            activeOpacity={0.8}
          >
            <Text style={styles.logoutText}>⇥ LOGOUT</Text>
          </TouchableOpacity>

          <Text style={styles.dashboardFooter}>MY APP • UTS MOBILE 1</Text>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    backgroundColor: "#f1f5f9",
  },

  // LOGIN
  loginContainer: {
    flexGrow: 1,
    justifyContent: "center",
    paddingHorizontal: 25,
    paddingVertical: 35,
  },
  logo: {
    width: 78,
    height: 78,
    borderRadius: 24,
    backgroundColor: "#2563eb",
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 18,
    elevation: 5,
  },
  logoText: {
    color: "#ffffff",
    fontSize: 38,
    fontWeight: "bold",
  },
  title: {
    fontSize: 30,
    fontWeight: "bold",
    color: "#1d4ed8",
    textAlign: "center",
  },
  subtitle: {
    fontSize: 19,
    fontWeight: "600",
    color: "#1e293b",
    textAlign: "center",
    marginTop: 12,
  },
  description: {
    fontSize: 13,
    color: "#64748b",
    textAlign: "center",
    marginTop: 7,
    marginBottom: 30,
  },
  form: {
    backgroundColor: "#ffffff",
    padding: 22,
    borderRadius: 20,
    elevation: 4,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#334155",
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: "#dbe3ef",
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 13,
    fontSize: 14,
    color: "#1e293b",
    marginBottom: 20,
  },
  passwordBox: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#dbe3ef",
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginBottom: 22,
  },
  passwordInput: {
    flex: 1,
    paddingVertical: 13,
    fontSize: 14,
    color: "#1e293b",
  },
  showPassword: {
    color: "#2563eb",
    fontSize: 12,
    fontWeight: "bold",
    padding: 5,
  },
  loginButton: {
    backgroundColor: "#2563eb",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
    elevation: 3,
  },
  loginButtonText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "bold",
  },
  footer: {
    textAlign: "center",
    color: "#94a3b8",
    fontSize: 12,
    marginTop: 28,
  },

  // DASHBOARD
  dashboardContainer: {
    paddingBottom: 25,
  },
  header: {
    backgroundColor: "#2563eb",
    paddingHorizontal: 23,
    paddingTop: 30,
    paddingBottom: 55,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerSmall: {
    color: "#dbeafe",
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 1,
  },
  headerTitle: {
    color: "#ffffff",
    fontSize: 27,
    fontWeight: "bold",
    marginTop: 6,
  },
  headerLogo: {
    width: 48,
    height: 48,
    backgroundColor: "#ffffff",
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  headerLogoText: {
    color: "#2563eb",
    fontSize: 25,
    fontWeight: "bold",
  },
  welcomeCard: {
    backgroundColor: "#ffffff",
    marginHorizontal: 20,
    marginTop: -32,
    padding: 18,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    elevation: 4,
  },
  avatar: {
    width: 62,
    height: 62,
    backgroundColor: "#dbeafe",
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 14,
  },
  avatarText: {
    fontSize: 22,
    color: "#2563eb",
    fontWeight: "bold",
  },
  profileInfo: {
    flex: 1,
  },
  welcomeText: {
    color: "#64748b",
    fontSize: 12,
  },
  name: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#1e293b",
    marginTop: 5,
  },
  emailText: {
    color: "#64748b",
    fontSize: 11,
    marginTop: 5,
  },
  sectionHeader: {
    marginHorizontal: 22,
    marginTop: 30,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 21,
    fontWeight: "bold",
    color: "#1e293b",
  },
  sectionSubtitle: {
    fontSize: 12,
    color: "#64748b",
    marginTop: 5,
  },
  menuContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginHorizontal: 20,
  },
  menuCard: {
    width: "48%",
    backgroundColor: "#ffffff",
    padding: 14,
    borderRadius: 17,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    elevation: 2,
  },
  menuTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  menuIcon: {
    width: 44,
    height: 44,
    backgroundColor: "#eff6ff",
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  iconText: {
    fontSize: 22,
  },
  menuNumber: {
    color: "#94a3b8",
    fontSize: 12,
    fontWeight: "bold",
  },
  menuTitle: {
    fontSize: 15,
    color: "#1e293b",
    fontWeight: "bold",
  },
  menuDescription: {
    fontSize: 10,
    color: "#64748b",
    marginTop: 5,

    minHeight: 25,
  },
  menuArrow: {
    fontSize: 11,
    color: "#2563eb",
    fontWeight: "bold",
    marginTop: 10,
  },
  infoCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginHorizontal: 20,
    marginTop: 8,
    padding: 16,
    backgroundColor: "#dbeafe",
    borderRadius: 16,
  },
  infoIcon: {
    fontSize: 25,
    marginRight: 12,
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 14,
    color: "#1d4ed8",
    fontWeight: "bold",
    marginBottom: 5,
  },
  infoText: {
    fontSize: 12,
    color: "#334155",
    lineHeight: 19,
  },
  logoutButton: {
    marginHorizontal: 20,
    marginTop: 22,
    padding: 15,
    borderRadius: 12,
    backgroundColor: "#fee2e2",
    borderWidth: 1,
    borderColor: "#fecaca",
    alignItems: "center",
  },
  logoutText: {
    color: "#dc2626",
    fontSize: 14,
    fontWeight: "bold",
  },
  dashboardFooter: {
    textAlign: "center",
    marginTop: 20,
    color: "#94a3b8",
    fontSize: 11,
  },
});
